namespace PerformanceTacticsDemo.Infrastructure;

public sealed class Debouncer
{
    private CancellationTokenSource? _cts;

    public async Task ExecuteAsync(
        TimeSpan delay,
        Func<CancellationToken, Task> action)
    {
        _cts?.Cancel();
        _cts?.Dispose();
        _cts = new CancellationTokenSource();

        try
        {
            await Task.Delay(delay, _cts.Token);
            await action(_cts.Token);
        }
        catch (OperationCanceledException)
        {
            // Expected when a newer event replaces this operation.
        }
    }
}
