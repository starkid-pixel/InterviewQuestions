namespace PerformanceTacticsDemo.Infrastructure;

public class PriorityWorkQueue<T>
{
    private readonly PriorityQueue<T, int> _queue = new();

    public void Enqueue(T item, int priority) =>
        _queue.Enqueue(item, priority);

    public bool TryDequeue(out T? item) =>
        _queue.TryDequeue(out item, out _);

    public int Count => _queue.Count;
}
