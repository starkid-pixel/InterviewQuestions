using System.Windows;
using PerformanceTacticsDemo.Services;
using PerformanceTacticsDemo.ViewModels;

namespace PerformanceTacticsDemo;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();

        var productService = new ProductService();
        var productCache = new ProductCache();
        var exportService = new ExportService();

        DataContext = new MainViewModel(
            productService,
            productCache,
            exportService);
    }
}
