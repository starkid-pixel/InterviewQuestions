using System.Windows;

namespace PerformanceTacticsDemo;

public partial class App : Application
{
}
