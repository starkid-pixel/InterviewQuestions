using PerformanceTacticsDemo.Models;

namespace PerformanceTacticsDemo.Services;

public class ProductService
{
    private readonly List<Product> _products;

    public ProductService()
    {
        _products = Enumerable
            .Range(1, 100_000)
            .Select(i => new Product
            {
                Id = i,
                Name = $"Product {i}",
                Price = Random.Shared.Next(10, 10_000),
                Category = $"Category {i % 10}"
            })
            .ToList();
    }

    public async Task<List<Product>> SearchAsync(
        string searchText,
        CancellationToken cancellationToken = default)
    {
        await Task.Delay(300, cancellationToken);

        return _products
            .Where(p => p.Name.Contains(
                searchText,
                StringComparison.OrdinalIgnoreCase))
            .Take(100)
            .ToList();
    }

    public async Task<Product?> GetByIdAsync(
        int id,
        CancellationToken cancellationToken = default)
    {
        await Task.Delay(300, cancellationToken);
        return _products.FirstOrDefault(x => x.Id == id);
    }

    public async Task<List<Product>> GetPageAsync(
        int pageNumber,
        int pageSize)
    {
        await Task.Delay(100);

        return _products
            .Skip((pageNumber - 1) * pageSize)
            .Take(pageSize)
            .ToList();
    }

    public int TotalCount => _products.Count;

    public async IAsyncEnumerable<Product> StreamAllAsync()
    {
        foreach (var product in _products)
        {
            await Task.Delay(1);
            yield return product;
        }
    }
}
