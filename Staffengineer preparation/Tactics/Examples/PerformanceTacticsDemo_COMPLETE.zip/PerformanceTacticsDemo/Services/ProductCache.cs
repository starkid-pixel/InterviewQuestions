using PerformanceTacticsDemo.Models;

namespace PerformanceTacticsDemo.Services;

public class ProductCache
{
    private readonly Dictionary<int, Product> _cache = new();

    public bool TryGet(
        int id,
        out Product? product) =>
        _cache.TryGetValue(id, out product);

    public void Set(Product product) =>
        _cache[product.Id] = product;
}
