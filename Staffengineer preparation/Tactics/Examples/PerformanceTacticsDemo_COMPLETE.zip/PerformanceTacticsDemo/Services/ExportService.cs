using PerformanceTacticsDemo.Models;

namespace PerformanceTacticsDemo.Services;

public class ExportService
{
    public async Task ExportAsync(
        IAsyncEnumerable<Product> products,
        int chunkSize,
        int maxConcurrency,
        IProgress<int>? progress = null,
        CancellationToken cancellationToken = default)
    {
        var buffer = new List<Product>();
        var processed = 0;

        using var semaphore =
            new SemaphoreSlim(maxConcurrency);

        var tasks = new List<Task>();

        async Task ProcessChunkAsync(
            List<Product> chunk)
        {
            await semaphore.WaitAsync(
                cancellationToken);

            try
            {
                await ExportChunkAsync(
                    chunk,
                    cancellationToken);

                var current = Interlocked.Add(
                    ref processed,
                    chunk.Count);

                progress?.Report(current);
            }
            finally
            {
                semaphore.Release();
            }
        }

        await foreach (
            var product in products.WithCancellation(
                cancellationToken))
        {
            buffer.Add(product);

            if (buffer.Count < chunkSize)
                continue;

            var chunk = buffer.ToList();
            buffer.Clear();

            tasks.Add(ProcessChunkAsync(chunk));
        }

        if (buffer.Count > 0)
            tasks.Add(ProcessChunkAsync(
                buffer.ToList()));

        await Task.WhenAll(tasks);
    }

    private static async Task ExportChunkAsync(
        List<Product> products,
        CancellationToken cancellationToken)
    {
        // Simulates writing a chunk to a file/service.
        await Task.Delay(50, cancellationToken);
    }
}
