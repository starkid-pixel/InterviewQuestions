using System.Windows.Controls;

namespace PerformanceTacticsDemo.Views;

public partial class CacheView : UserControl
{
    public CacheView() => InitializeComponent();
}
