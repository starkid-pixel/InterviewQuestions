using System.Windows.Controls;

namespace PerformanceTacticsDemo.Views;

public partial class ExportView : UserControl
{
    public ExportView() => InitializeComponent();
}
