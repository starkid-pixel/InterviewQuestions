using System.Windows;
using System.Windows.Controls;
using PerformanceTacticsDemo.ViewModels;

namespace PerformanceTacticsDemo.Views;

public partial class PriorityAlertsView : UserControl
{
    public PriorityAlertsView() => InitializeComponent();

    private void ProcessNext_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is PriorityAlertsViewModel vm)
            vm.ProcessNext();
    }
}
