using System.Windows.Controls;

namespace PerformanceTacticsDemo.Views;

public partial class SearchView : UserControl
{
    public SearchView() => InitializeComponent();
}
