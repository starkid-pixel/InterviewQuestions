using System.Windows;
using System.Windows.Controls;
using PerformanceTacticsDemo.Models;
using PerformanceTacticsDemo.ViewModels;

namespace PerformanceTacticsDemo.Views;

public partial class BatchUpdatesView : UserControl
{
    public BatchUpdatesView() => InitializeComponent();

    private void GenerateUpdates_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is BatchUpdatesViewModel vm)
        {
            for (int i = 0; i < 20; i++)
            {
                vm.ReceiveUpdate(new ProductUpdate
                {
                    ProductId = (i % 3) + 1,
                    NewPrice = 100 + i,
                    Timestamp = DateTime.Now
                });
            }
        }
    }
}
