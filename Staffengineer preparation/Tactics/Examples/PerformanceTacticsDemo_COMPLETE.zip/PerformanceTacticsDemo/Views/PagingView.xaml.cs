using System.Windows.Controls;

namespace PerformanceTacticsDemo.Views;

public partial class PagingView : UserControl
{
    public PagingView() => InitializeComponent();
}
