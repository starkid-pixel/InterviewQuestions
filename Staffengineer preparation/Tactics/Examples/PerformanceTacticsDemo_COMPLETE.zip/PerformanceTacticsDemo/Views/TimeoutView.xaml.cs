using System.Windows.Controls;

namespace PerformanceTacticsDemo.Views;

public partial class TimeoutView : UserControl
{
    public TimeoutView() => InitializeComponent();
}
