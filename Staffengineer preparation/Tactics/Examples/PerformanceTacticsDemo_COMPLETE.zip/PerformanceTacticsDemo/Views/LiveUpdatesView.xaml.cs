using System.Windows.Controls;

namespace PerformanceTacticsDemo.Views;

public partial class LiveUpdatesView : UserControl
{
    public LiveUpdatesView() => InitializeComponent();
}
