# Control Resource Demand — WPF Performance Demo

This demo uses one Product Monitoring Dashboard to demonstrate six
**Control Resource Demand** tactics through eight concrete scenarios.

## Tactic mapping

| Scenario | Tactic | Implementation |
|---|---|---|
| Search | Limit Event Response | Debouncing |
| Live updates | Manage Sampling Rate | Throttling / latest-value sampling |
| Incoming updates | Limit Event Response + Reduce Overhead | Event coalescing + batching |
| Alerts | Prioritize Events | Priority Queue |
| Product grid | Reduce Overhead | Paging |
| Product grid UI | Resource efficiency | UI virtualization |
| Product details | Reduce Overhead | Caching |
| Slow operation | Bound Execution Times | Timeout + cancellation |
| Export | Increase Resource Efficiency | Streaming + chunking + concurrency control |

## Architecture

```text
Performance Efficiency
        ↓
Control Resource Demand
        ↓
Tactics
        ↓
Concrete approaches
        ↓
Technology implementation
        ↓
WPF UI
```

## Scenarios

1. Search + Debouncing
2. Live Updates + Throttling
3. Batching + Event Coalescing
4. Priority Queue
5. Paging + UI Virtualization
6. Product Detail Caching
7. Timeout + Cancellation
8. Export + Streaming + Chunking + Concurrency Control

The project intentionally uses fake/in-memory data so the performance
tactics remain easy to observe without adding backend infrastructure.
