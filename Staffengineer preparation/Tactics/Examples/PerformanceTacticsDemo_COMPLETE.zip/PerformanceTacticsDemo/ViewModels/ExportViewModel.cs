using System.Windows.Input;
using PerformanceTacticsDemo.Infrastructure;
using PerformanceTacticsDemo.Services;

namespace PerformanceTacticsDemo.ViewModels;

public class ExportViewModel : ObservableObject
{
    private readonly ProductService _productService;
    private readonly ExportService _exportService;

    private string _status = "Ready";
    private int _processed;

    public string Status
    {
        get => _status;
        set => SetProperty(
            ref _status,
            value);
    }

    public int Processed
    {
        get => _processed;
        set => SetProperty(
            ref _processed,
            value);
    }

    public ICommand ExportCommand { get; }

    public ExportViewModel(
        ProductService productService,
        ExportService exportService)
    {
        _productService = productService;
        _exportService = exportService;

        ExportCommand =
            new RelayCommand(
                async () => await ExportAsync());
    }

    private async Task ExportAsync()
    {
        Status = "Exporting...";
        Processed = 0;

        var progress =
            new Progress<int>(
                value => Processed = value);

        try
        {
            await _exportService.ExportAsync(
                _productService.StreamAllAsync(),
                chunkSize: 1000,
                maxConcurrency: 5,
                progress: progress);

            Status = "Completed";
        }
        catch (OperationCanceledException)
        {
            Status = "Cancelled";
        }
    }
}
