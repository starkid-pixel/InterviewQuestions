using System.Windows.Input;
using PerformanceTacticsDemo.Infrastructure;
using PerformanceTacticsDemo.Models;
using PerformanceTacticsDemo.Services;

namespace PerformanceTacticsDemo.ViewModels;

public class CacheViewModel : ObservableObject
{
    private readonly ProductService _productService;
    private readonly ProductCache _cache;

    private int _productId = 1;
    private Product? _product;
    private string _source = string.Empty;

    public int ProductId
    {
        get => _productId;
        set => SetProperty(
            ref _productId,
            value);
    }

    public Product? Product
    {
        get => _product;
        set => SetProperty(
            ref _product,
            value);
    }

    public string Source
    {
        get => _source;
        set => SetProperty(
            ref _source,
            value);
    }

    public ICommand LoadCommand { get; }

    public CacheViewModel(
        ProductService productService,
        ProductCache cache)
    {
        _productService = productService;
        _cache = cache;

        LoadCommand =
            new RelayCommand(
                async () =>
                    await LoadProductAsync());
    }

    private async Task LoadProductAsync()
    {
        if (_cache.TryGet(
            ProductId,
            out var cachedProduct))
        {
            Product = cachedProduct;
            Source = "Loaded from CACHE";
            return;
        }

        Product =
            await _productService.GetByIdAsync(
                ProductId);

        if (Product is not null)
            _cache.Set(Product);

        Source = "Loaded from SERVICE";
    }
}
