using PerformanceTacticsDemo.Infrastructure;

namespace PerformanceTacticsDemo.ViewModels;

public class LiveUpdatesViewModel : ObservableObject
{
    private decimal _latestPrice;
    private decimal _displayedPrice;

    private readonly PeriodicTimer _timer =
        new(TimeSpan.FromMilliseconds(500));

    public decimal DisplayedPrice
    {
        get => _displayedPrice;
        set => SetProperty(
            ref _displayedPrice,
            value);
    }

    public LiveUpdatesViewModel()
    {
        _ = StartThrottledUpdatesAsync();
        _ = StartSimulatedProducerAsync();
    }

    private async Task StartThrottledUpdatesAsync()
    {
        while (await _timer.WaitForNextTickAsync())
            DisplayedPrice = _latestPrice;
    }

    private async Task StartSimulatedProducerAsync()
    {
        while (true)
        {
            _latestPrice =
                Random.Shared.Next(10, 1000);

            await Task.Delay(20);
        }
    }
}
