using PerformanceTacticsDemo.Infrastructure;
using PerformanceTacticsDemo.Services;

namespace PerformanceTacticsDemo.ViewModels;

public class MainViewModel : ObservableObject
{
    public SearchViewModel Search { get; }
    public LiveUpdatesViewModel LiveUpdates { get; }
    public BatchUpdatesViewModel BatchUpdates { get; }
    public PriorityAlertsViewModel PriorityAlerts { get; }
    public PagingViewModel Paging { get; }
    public CacheViewModel Cache { get; }
    public TimeoutViewModel Timeout { get; }
    public ExportViewModel Export { get; }

    public MainViewModel(
        ProductService productService,
        ProductCache productCache,
        ExportService exportService)
    {
        Search = new SearchViewModel(productService);
        LiveUpdates = new LiveUpdatesViewModel();
        BatchUpdates = new BatchUpdatesViewModel();
        PriorityAlerts = new PriorityAlertsViewModel();
        Paging = new PagingViewModel(productService);
        Cache = new CacheViewModel(
            productService,
            productCache);
        Timeout = new TimeoutViewModel();
        Export = new ExportViewModel(
            productService,
            exportService);
    }
}
