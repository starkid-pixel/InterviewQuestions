using System.Collections.ObjectModel;
using System.Windows.Input;
using PerformanceTacticsDemo.Infrastructure;
using PerformanceTacticsDemo.Models;
using PerformanceTacticsDemo.Services;

namespace PerformanceTacticsDemo.ViewModels;

public class PagingViewModel : ObservableObject
{
    private readonly ProductService _productService;
    private int _currentPage = 1;

    public int PageSize { get; } = 100;

    public int CurrentPage
    {
        get => _currentPage;
        set => SetProperty(
            ref _currentPage,
            value);
    }

    public ObservableCollection<Product>
        Products { get; } = new();

    public ICommand NextPageCommand { get; }
    public ICommand PreviousPageCommand { get; }

    public PagingViewModel(
        ProductService productService)
    {
        _productService = productService;

        NextPageCommand = new RelayCommand(
            async () =>
            {
                CurrentPage++;
                await LoadPageAsync();
            });

        PreviousPageCommand = new RelayCommand(
            async () =>
            {
                if (CurrentPage > 1)
                    CurrentPage--;

                await LoadPageAsync();
            },
            () => CurrentPage > 1);

        _ = LoadPageAsync();
    }

    private async Task LoadPageAsync()
    {
        var page =
            await _productService.GetPageAsync(
                CurrentPage,
                PageSize);

        Products.Clear();

        foreach (var product in page)
            Products.Add(product);

        if (PreviousPageCommand
            is RelayCommand previous)
        {
            previous.RaiseCanExecuteChanged();
        }
    }
}
