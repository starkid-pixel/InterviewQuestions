using System.Collections.ObjectModel;
using PerformanceTacticsDemo.Infrastructure;
using PerformanceTacticsDemo.Models;

namespace PerformanceTacticsDemo.ViewModels;

public class BatchUpdatesViewModel : ObservableObject
{
    private readonly Dictionary<int, ProductUpdate>
        _latestUpdates = new();

    private readonly PeriodicTimer _timer =
        new(TimeSpan.FromMilliseconds(500));

    public ObservableCollection<string>
        ProcessedUpdates { get; } = new();

    public BatchUpdatesViewModel()
    {
        _ = StartBatchProcessorAsync();
    }

    public void ReceiveUpdate(
        ProductUpdate update)
    {
        lock (_latestUpdates)
        {
            // Event coalescing:
            // keep only the latest update per product.
            _latestUpdates[update.ProductId] = update;
        }
    }

    private async Task StartBatchProcessorAsync()
    {
        while (await _timer.WaitForNextTickAsync())
        {
            List<ProductUpdate> batch;

            lock (_latestUpdates)
            {
                batch = _latestUpdates.Values.ToList();
                _latestUpdates.Clear();
            }

            foreach (var update in batch)
            {
                ProcessedUpdates.Add(
                    $"Product {update.ProductId} -> " +
                    $"{update.NewPrice}");
            }
        }
    }
}
