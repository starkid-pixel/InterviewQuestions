using System.Collections.ObjectModel;
using PerformanceTacticsDemo.Infrastructure;
using PerformanceTacticsDemo.Models;

namespace PerformanceTacticsDemo.ViewModels;

public class PriorityAlertsViewModel : ObservableObject
{
    private readonly PriorityWorkQueue<Alert> _queue = new();

    public ObservableCollection<Alert>
        ProcessedAlerts { get; } = new();

    public PriorityAlertsViewModel()
    {
        _queue.Enqueue(
            new Alert
            {
                Message = "Telemetry Update",
                Priority = AlertPriority.Low
            },
            (int)AlertPriority.Low);

        _queue.Enqueue(
            new Alert
            {
                Message = "User Order Failed",
                Priority = AlertPriority.High
            },
            (int)AlertPriority.High);

        _queue.Enqueue(
            new Alert
            {
                Message = "System Down",
                Priority = AlertPriority.Critical
            },
            (int)AlertPriority.Critical);
    }

    public void ProcessNext()
    {
        if (_queue.TryDequeue(out var alert) &&
            alert is not null)
        {
            ProcessedAlerts.Add(alert);
        }
    }
}
