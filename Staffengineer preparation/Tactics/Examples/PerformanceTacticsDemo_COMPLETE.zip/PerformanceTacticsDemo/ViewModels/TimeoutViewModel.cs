using System.Windows.Input;
using PerformanceTacticsDemo.Infrastructure;

namespace PerformanceTacticsDemo.ViewModels;

public class TimeoutViewModel : ObservableObject
{
    private CancellationTokenSource? _cts;
    private string _status = "Ready";

    public string Status
    {
        get => _status;
        set => SetProperty(
            ref _status,
            value);
    }

    public ICommand StartCommand { get; }
    public ICommand CancelCommand { get; }

    public TimeoutViewModel()
    {
        StartCommand =
            new RelayCommand(
                async () => await StartAsync());

        CancelCommand =
            new RelayCommand(
                () => _cts?.Cancel());
    }

    private async Task StartAsync()
    {
        _cts?.Cancel();
        _cts = new CancellationTokenSource();

        using var timeoutCts =
            new CancellationTokenSource(
                TimeSpan.FromSeconds(5));

        using var linkedCts =
            CancellationTokenSource
                .CreateLinkedTokenSource(
                    _cts.Token,
                    timeoutCts.Token);

        try
        {
            Status = "Processing...";

            await SimulateSlowOperationAsync(
                linkedCts.Token);

            Status = "Completed";
        }
        catch (OperationCanceledException)
        {
            Status =
                timeoutCts.IsCancellationRequested
                    ? "Timed out"
                    : "Cancelled";
        }
    }

    private static Task
        SimulateSlowOperationAsync(
            CancellationToken token) =>
        Task.Delay(
            TimeSpan.FromSeconds(10),
            token);
}
