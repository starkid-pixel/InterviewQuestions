using System.Collections.ObjectModel;
using PerformanceTacticsDemo.Infrastructure;
using PerformanceTacticsDemo.Models;
using PerformanceTacticsDemo.Services;

namespace PerformanceTacticsDemo.ViewModels;

public class SearchViewModel : ObservableObject
{
    private readonly ProductService _productService;
    private readonly Debouncer _debouncer = new();
    private string _searchText = string.Empty;

    public ObservableCollection<Product> Results { get; } = new();

    public string SearchText
    {
        get => _searchText;
        set
        {
            if (SetProperty(
                ref _searchText,
                value))
            {
                _ = SearchDebouncedAsync(value);
            }
        }
    }

    public SearchViewModel(
        ProductService productService)
    {
        _productService = productService;
    }

    private async Task SearchDebouncedAsync(
        string searchText)
    {
        await _debouncer.ExecuteAsync(
            TimeSpan.FromMilliseconds(500),
            async cancellationToken =>
            {
                var products =
                    await _productService.SearchAsync(
                        searchText,
                        cancellationToken);

                Results.Clear();

                foreach (var product in products)
                    Results.Add(product);
            });
    }
}
