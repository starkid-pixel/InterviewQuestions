namespace PerformanceTacticsDemo.Models;

public enum AlertPriority
{
    Critical = 0,
    High = 1,
    Normal = 2,
    Low = 3
}

public class Alert
{
    public string Message { get; init; } = string.Empty;
    public AlertPriority Priority { get; init; }

    public override string ToString() =>
        $"[{Priority}] {Message}";
}
