namespace PerformanceTacticsDemo.Models;

public class Product
{
    public int Id { get; init; }
    public string Name { get; init; } = string.Empty;
    public decimal Price { get; init; }
    public string Category { get; init; } = string.Empty;

    public override string ToString() =>
        $"{Id} - {Name} - {Price:C}";
}
