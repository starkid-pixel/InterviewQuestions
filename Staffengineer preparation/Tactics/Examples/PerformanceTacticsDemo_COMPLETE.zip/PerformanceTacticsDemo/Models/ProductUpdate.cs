namespace PerformanceTacticsDemo.Models;

public class ProductUpdate
{
    public int ProductId { get; init; }
    public decimal NewPrice { get; init; }
    public DateTime Timestamp { get; init; }
}
