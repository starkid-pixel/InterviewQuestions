namespace PerformanceArchitectureApp.Shared.Infrastructure;

public static class AsyncEnumerableExtensions
{
    public static async IAsyncEnumerable<T[]> ChunkAsync<T>(
        this IAsyncEnumerable<T> source, int size)
    {
        if (size <= 0) throw new ArgumentOutOfRangeException(nameof(size));

        var buffer = new List<T>(size);

        await foreach (var item in source)
        {
            buffer.Add(item);
            if (buffer.Count == size)
            {
                yield return buffer.ToArray();
                buffer.Clear();
            }
        }

        if (buffer.Count > 0)
            yield return buffer.ToArray();
    }
}