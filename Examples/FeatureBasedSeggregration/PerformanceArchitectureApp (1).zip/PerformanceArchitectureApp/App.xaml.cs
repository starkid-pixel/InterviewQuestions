using Microsoft.Extensions.DependencyInjection;
using System.Windows;
using PerformanceArchitectureApp.Navigation;
using PerformanceArchitectureApp.Shell;
using PerformanceArchitectureApp.Modules.ProductSearch;
using PerformanceArchitectureApp.Modules.LiveMonitoring;
using PerformanceArchitectureApp.Modules.DataManagement;
using PerformanceArchitectureApp.Modules.Processing;
using PerformanceArchitectureApp.Modules.Reporting;

namespace PerformanceArchitectureApp;

public partial class App : Application
{
    private ServiceProvider? _serviceProvider;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        var services = new ServiceCollection();
        ConfigureServices(services);
        _serviceProvider = services.BuildServiceProvider();

        _serviceProvider.GetRequiredService<ShellView>().Show();
    }

    private static void ConfigureServices(IServiceCollection services)
    {
        services.AddSingleton<INavigationService>(sp => new NavigationService(sp));

        services.AddSingleton<ProductSearchService>();
        services.AddTransient<ProductSearchViewModel>();
        services.AddTransient<ProductSearchView>();

        services.AddSingleton<LiveDataService>();
        services.AddTransient<LiveMonitoringViewModel>();
        services.AddTransient<LiveMonitoringView>();

        services.AddSingleton<ProductRepository>();
        services.AddSingleton<ProductCache>();
        services.AddTransient<DataManagementViewModel>();
        services.AddTransient<DataManagementView>();

        services.AddSingleton<BatchProcessor>();
        services.AddTransient<ProcessingViewModel>();
        services.AddTransient<ProcessingView>();

        services.AddSingleton<ReportExportService>();
        services.AddTransient<ReportingViewModel>();
        services.AddTransient<ReportingView>();

        services.AddSingleton<ShellViewModel>();
        services.AddSingleton<ShellView>();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _serviceProvider?.Dispose();
        base.OnExit(e);
    }
}