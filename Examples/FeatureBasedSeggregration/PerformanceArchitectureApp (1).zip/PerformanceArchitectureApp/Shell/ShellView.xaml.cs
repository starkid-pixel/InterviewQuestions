using System.Windows;

namespace PerformanceArchitectureApp.Shell;

public partial class ShellView : Window
{
    public ShellView(ShellViewModel viewModel)
    {
        InitializeComponent();
        DataContext = viewModel;
    }
}