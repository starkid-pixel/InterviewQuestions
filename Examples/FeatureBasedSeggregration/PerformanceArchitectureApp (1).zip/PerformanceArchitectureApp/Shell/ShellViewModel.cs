using PerformanceArchitectureApp.Navigation;
using PerformanceArchitectureApp.Shared.Infrastructure;
using PerformanceArchitectureApp.Modules.ProductSearch;
using PerformanceArchitectureApp.Modules.LiveMonitoring;
using PerformanceArchitectureApp.Modules.DataManagement;
using PerformanceArchitectureApp.Modules.Processing;
using PerformanceArchitectureApp.Modules.Reporting;

namespace PerformanceArchitectureApp.Shell;

public sealed class ShellViewModel : ObservableObject
{
    private readonly INavigationService _navigationService;

    public ObservableObject? CurrentViewModel => _navigationService.CurrentViewModel;

    public RelayCommand NavigateToSearchCommand { get; }
    public RelayCommand NavigateToMonitoringCommand { get; }
    public RelayCommand NavigateToDataCommand { get; }
    public RelayCommand NavigateToProcessingCommand { get; }
    public RelayCommand NavigateToReportingCommand { get; }

    public ShellViewModel(INavigationService navigationService)
    {
        _navigationService = navigationService;

        _navigationService.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName == nameof(INavigationService.CurrentViewModel))
                OnPropertyChanged(nameof(CurrentViewModel));
        };

        NavigateToSearchCommand = new RelayCommand(() =>
            _navigationService.NavigateTo<ProductSearchViewModel>());
        NavigateToMonitoringCommand = new RelayCommand(() =>
            _navigationService.NavigateTo<LiveMonitoringViewModel>());
        NavigateToDataCommand = new RelayCommand(() =>
            _navigationService.NavigateTo<DataManagementViewModel>());
        NavigateToProcessingCommand = new RelayCommand(() =>
            _navigationService.NavigateTo<ProcessingViewModel>());
        NavigateToReportingCommand = new RelayCommand(() =>
            _navigationService.NavigateTo<ReportingViewModel>());

        _navigationService.NavigateTo<ProductSearchViewModel>();
    }
}