# PerformanceArchitectureApp

## Architecture

This is a **modular, feature-based WPF application using MVVM and
dependency injection**.

The top-level organization is by feature:

``` text
Application
├── Shell
├── Navigation
├── ProductSearch
├── LiveMonitoring
├── DataManagement
├── Processing
├── Reporting
└── Shared
```

The modules can internally follow logical layers:

``` text
View
  |
ViewModel
  |
Service / Repository
  |
Infrastructure / Data source
```

So the most accurate description is:

> **Modules horizontally, layers vertically.**

## Startup and Main UI

`App.xaml` intentionally has no `StartupUri`.

`App.xaml.cs` is the Composition Root:

``` text
App
 |
DI Container
 |
ShellView
 |
ShellViewModel
```

The Shell is therefore the application's main UI.

The startup sequence is:

1.  WPF starts `App`.
2.  `OnStartup` executes.
3.  Services are registered.
4.  The DI container is built.
5.  `ShellView` is resolved.
6.  `ShellView.Show()` displays the main UI.
7.  `ShellViewModel` navigates to the initial Product Search module.

## Shell

The Shell contains:

-   navigation menu on the left
-   content region on the right

The content region is:

``` xml
<ContentControl Grid.Column="1"
                Content="{Binding CurrentViewModel}" />
```

WPF `DataTemplate`s map ViewModels to Views:

``` text
ProductSearchViewModel  -> ProductSearchView
LiveMonitoringViewModel -> LiveMonitoringView
DataManagementViewModel -> DataManagementView
ProcessingViewModel     -> ProcessingView
ReportingViewModel      -> ReportingView
```

Navigation changes `CurrentViewModel`, which causes the content region
to display the corresponding View.

## Module 1: Product Search

Demonstrates **debouncing**.

``` text
User types
    |
SearchText changes
    |
Debouncer waits 500 ms
    |
Search service
    |
Results
```

If another character is entered before the delay expires, the previous
pending search is cancelled.

## Module 2: Live Monitoring

Demonstrates high-frequency data with lower-frequency UI updates.

The sample receives data approximately every 20 ms, while the UI samples
the latest value every 500 ms.

``` text
Fast data stream
       |
       v
latest value
       |
500 ms sampling
       |
       v
UI
```

## Module 3: Data Management

Demonstrates:

-   paging
-   caching

Only a page of 100 records is loaded into the UI instead of displaying
all 100,000 records.

``` text
Repository
    |
    +-- page 1
    +-- page 2
    +-- page 3
```

Loaded products are also placed in `ProductCache`.

## Module 4: Processing

Demonstrates:

-   batching
-   chunking
-   cancellation through a timeout

10,000 items are processed in batches of 500 with a five-second timeout.

``` text
10,000 items
     |
     v
batches of 500
     |
     v
process
     |
5 second timeout
```

## Module 5: Reporting

Demonstrates:

-   `IAsyncEnumerable<T>`
-   streaming
-   chunking

The export service produces records asynchronously. The ViewModel
consumes them in chunks of 500.

``` text
Async stream
     |
     v
500-record chunk
     |
     v
UI progress
```

## MVVM responsibilities

### View

Responsible for:

-   layout
-   controls
-   bindings
-   visual representation

### ViewModel

Responsible for:

-   UI state
-   commands
-   binding properties
-   invoking module services

### Service / Repository

Responsible for:

-   module operations
-   data access
-   processing logic
-   external interactions

## Why this is not purely layer-based

A pure layer-based structure would look like:

``` text
Views/
ViewModels/
Services/
Repositories/
```

The solution instead groups related code by feature:

``` text
ProductSearch/
DataManagement/
Processing/
Reporting/
```

This keeps a feature's UI and supporting logic together.

## DI lifetimes

The sample uses:

-   **Singleton** for long-lived services such as repositories, caches
    and data services.
-   **Transient** for module Views and ViewModels.
-   **Singleton** for Shell and NavigationService.

The transient ViewModel choice means a new ViewModel can be created when
navigating to a module. If state must survive navigation, a navigation
cache or a different lifetime can be introduced.

## Module communication

Modules should not directly create or manipulate other modules'
ViewModels.

Prefer:

``` text
Module
  |
  +--> Navigation Service
  |
  +--> Shared service / contract
  |
  +--> Event/message mechanism
```

This keeps module boundaries clearer.

## Production improvements

This repository is an architectural starting point, not a complete
production framework.

For production, consider:

1.  Proper cancellation when leaving a module.
2.  Centralized exception handling.
3.  Logging and telemetry.
4.  Interfaces around external dependencies for unit testing.
5.  Real API/database implementations.
6.  Separate Infrastructure/Application projects when the solution
    grows.
7.  Explicit module registration abstractions when module count becomes
    large.
8.  Careful DI lifetime selection based on ownership and state.
9.  Navigation state preservation where required.
10. Avoiding UI-bound collection updates from worker threads.

## Interview description

A concise architecture description is:

> **A modular, feature-based WPF application using MVVM and dependency
> injection. The Shell provides navigation and a content region. Each
> feature module owns its View, ViewModel and module-specific services.
> Shared infrastructure is kept outside the feature modules. Modules can
> internally follow presentation/application/data layering.**

## Project tree

``` text
PerformanceArchitectureApp
|
+-- App.xaml
+-- App.xaml.cs
+-- PerformanceArchitectureApp.csproj
|
+-- Shell
|   +-- ShellView.xaml
|   +-- ShellView.xaml.cs
|   +-- ShellViewModel.cs
|
+-- Navigation
|   +-- INavigationService.cs
|   +-- NavigationService.cs
|
+-- Shared
|   +-- Infrastructure
|   |   +-- ObservableObject.cs
|   |   +-- RelayCommand.cs
|   |   +-- AsyncEnumerableExtensions.cs
|   |
|   +-- Models
|       +-- Product.cs
|
+-- Modules
    +-- ProductSearch
    +-- LiveMonitoring
    +-- DataManagement
    +-- Processing
    +-- Reporting
```
