using System.Windows.Controls;

namespace PerformanceArchitectureApp.Modules.LiveMonitoring;

public partial class LiveMonitoringView : UserControl
{
    public LiveMonitoringView() => InitializeComponent();
}