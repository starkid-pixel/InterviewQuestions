namespace PerformanceArchitectureApp.Modules.LiveMonitoring;

public sealed class LiveDataService
{
    public async IAsyncEnumerable<decimal> StreamAsync(
        [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            yield return Random.Shared.Next(10, 1000);
            await Task.Delay(20, token);
        }
    }
}