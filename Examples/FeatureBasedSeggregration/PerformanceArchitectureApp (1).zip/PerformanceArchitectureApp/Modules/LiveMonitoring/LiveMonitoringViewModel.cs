using PerformanceArchitectureApp.Shared.Infrastructure;

namespace PerformanceArchitectureApp.Modules.LiveMonitoring;

public sealed class LiveMonitoringViewModel : ObservableObject, IDisposable
{
    private readonly LiveDataService _service;
    private readonly CancellationTokenSource _cts = new();
    private decimal _latestValue;
    private decimal _displayedValue;
    private int _receivedEvents;
    private int _uiUpdates;

    public decimal DisplayedValue { get => _displayedValue; private set => SetProperty(ref _displayedValue, value); }
    public int ReceivedEvents => Volatile.Read(ref _receivedEvents);
    public int UiUpdates { get => _uiUpdates; private set => SetProperty(ref _uiUpdates, value); }

    public LiveMonitoringViewModel(LiveDataService service)
    {
        _service = service;
        _ = StartAsync();
    }

    private async Task StartAsync()
    {
        var producer = Task.Run(async () =>
        {
            try
            {
                await foreach (var value in _service.StreamAsync(_cts.Token))
                {
                    _latestValue = value;
                    Interlocked.Increment(ref _receivedEvents);
                }
            }
            catch (OperationCanceledException) { }
        });

        try
        {
            using var timer = new PeriodicTimer(TimeSpan.FromMilliseconds(500));
            while (await timer.WaitForNextTickAsync(_cts.Token))
            {
                DisplayedValue = _latestValue;
                UiUpdates++;
                OnPropertyChanged(nameof(ReceivedEvents));
            }
        }
        catch (OperationCanceledException) { }

        await producer;
    }

    public void Dispose() => _cts.Cancel();
}