namespace PerformanceArchitectureApp.Modules.Processing;

public sealed class BatchProcessor
{
    public async Task<int> ProcessAsync(
        IEnumerable<int> items, int batchSize, CancellationToken token)
    {
        var processed = 0;

        foreach (var batch in items.Chunk(batchSize))
        {
            token.ThrowIfCancellationRequested();
            await Task.Delay(200, token);
            processed += batch.Length;
        }

        return processed;
    }
}