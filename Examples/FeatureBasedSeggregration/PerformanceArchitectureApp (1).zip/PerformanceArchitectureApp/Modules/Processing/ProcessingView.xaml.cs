using System.Windows.Controls;

namespace PerformanceArchitectureApp.Modules.Processing;

public partial class ProcessingView : UserControl
{
    public ProcessingView() => InitializeComponent();
}