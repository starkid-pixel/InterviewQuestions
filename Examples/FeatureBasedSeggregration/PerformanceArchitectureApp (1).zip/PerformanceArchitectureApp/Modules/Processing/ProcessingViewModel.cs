using PerformanceArchitectureApp.Shared.Infrastructure;

namespace PerformanceArchitectureApp.Modules.Processing;

public sealed class ProcessingViewModel : ObservableObject
{
    private readonly BatchProcessor _processor;
    private string _status = "Ready";

    public string Status { get => _status; private set => SetProperty(ref _status, value); }
    public RelayCommand StartCommand { get; }

    public ProcessingViewModel(BatchProcessor processor)
    {
        _processor = processor;
        StartCommand = new RelayCommand(() => _ = StartAsync());
    }

    private async Task StartAsync()
    {
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));

        try
        {
            Status = "Processing batches...";
            var result = await _processor.ProcessAsync(
                Enumerable.Range(1, 10_000), 500, timeout.Token);
            Status = $"Processed {result} items";
        }
        catch (OperationCanceledException)
        {
            Status = "Processing timed out";
        }
    }
}