using PerformanceArchitectureApp.Shared.Models;

namespace PerformanceArchitectureApp.Modules.DataManagement;

public sealed class ProductRepository
{
    private readonly List<Product> _products =
        Enumerable.Range(1, 100_000)
        .Select(i => new Product
        {
            Id = i,
            Name = $"Product {i}",
            Price = Random.Shared.Next(10, 5000),
            Category = $"Category {i % 5}"
        }).ToList();

    public async Task<List<Product>> GetPageAsync(int page, int pageSize)
    {
        await Task.Delay(100);
        return _products.Skip((page - 1) * pageSize).Take(pageSize).ToList();
    }
}