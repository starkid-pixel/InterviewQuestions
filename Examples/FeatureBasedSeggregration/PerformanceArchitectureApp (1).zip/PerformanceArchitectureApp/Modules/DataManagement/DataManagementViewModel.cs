using System.Collections.ObjectModel;
using PerformanceArchitectureApp.Shared.Infrastructure;
using PerformanceArchitectureApp.Shared.Models;

namespace PerformanceArchitectureApp.Modules.DataManagement;

public sealed class DataManagementViewModel : ObservableObject
{
    private readonly ProductRepository _repository;
    private readonly ProductCache _cache;
    private int _page = 1;
    private string _status = "Ready";

    public ObservableCollection<Product> Products { get; } = [];
    public int Page { get => _page; private set => SetProperty(ref _page, value); }
    public string Status { get => _status; private set => SetProperty(ref _status, value); }

    public RelayCommand NextPageCommand { get; }
    public RelayCommand PreviousPageCommand { get; }

    public DataManagementViewModel(ProductRepository repository, ProductCache cache)
    {
        _repository = repository;
        _cache = cache;

        NextPageCommand = new RelayCommand(() => _ = NextPageAsync());
        PreviousPageCommand = new RelayCommand(() => _ = PreviousPageAsync(), () => Page > 1);

        _ = LoadPageAsync();
    }

    private async Task NextPageAsync()
    {
        Page++;
        PreviousPageCommand.RaiseCanExecuteChanged();
        await LoadPageAsync();
    }

    private async Task PreviousPageAsync()
    {
        if (Page <= 1) return;
        Page--;
        PreviousPageCommand.RaiseCanExecuteChanged();
        await LoadPageAsync();
    }

    private async Task LoadPageAsync()
    {
        Status = "Loading page...";
        var products = await _repository.GetPageAsync(Page, 100);

        Products.Clear();
        foreach (var product in products)
        {
            Products.Add(product);
            _cache.Set(product);
        }

        Status = $"Page {Page} loaded";
    }
}