using PerformanceArchitectureApp.Shared.Models;

namespace PerformanceArchitectureApp.Modules.DataManagement;

public sealed class ProductCache
{
    private readonly Dictionary<int, Product> _cache = [];

    public bool TryGet(int id, out Product? product) =>
        _cache.TryGetValue(id, out product);

    public void Set(Product product) => _cache[product.Id] = product;
    public void Clear() => _cache.Clear();
}