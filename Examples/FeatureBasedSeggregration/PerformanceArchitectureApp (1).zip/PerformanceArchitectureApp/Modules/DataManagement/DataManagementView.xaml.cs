using System.Windows.Controls;

namespace PerformanceArchitectureApp.Modules.DataManagement;

public partial class DataManagementView : UserControl
{
    public DataManagementView() => InitializeComponent();
}