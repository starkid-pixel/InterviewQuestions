using PerformanceArchitectureApp.Shared.Infrastructure;

namespace PerformanceArchitectureApp.Modules.Reporting;

public sealed class ReportingViewModel : ObservableObject
{
    private readonly ReportExportService _service;
    private int _processed;
    private string _status = "Ready";

    public int Processed { get => _processed; private set => SetProperty(ref _processed, value); }
    public string Status { get => _status; private set => SetProperty(ref _status, value); }
    public RelayCommand ExportCommand { get; }

    public ReportingViewModel(ReportExportService service)
    {
        _service = service;
        ExportCommand = new RelayCommand(() => _ = ExportAsync());
    }

    private async Task ExportAsync()
    {
        Processed = 0;
        Status = "Streaming data...";

        await foreach (var batch in _service.ExportAsync(CancellationToken.None).ChunkAsync(500))
        {
            Processed += batch.Length;
            Status = $"Processed {Processed} records";
        }

        Status = "Export complete";
    }
}