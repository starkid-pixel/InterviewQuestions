using System.Windows.Controls;

namespace PerformanceArchitectureApp.Modules.Reporting;

public partial class ReportingView : UserControl
{
    public ReportingView() => InitializeComponent();
}