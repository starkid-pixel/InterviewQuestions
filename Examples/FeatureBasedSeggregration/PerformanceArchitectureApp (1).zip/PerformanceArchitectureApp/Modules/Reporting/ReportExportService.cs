using PerformanceArchitectureApp.Shared.Models;

namespace PerformanceArchitectureApp.Modules.Reporting;

public sealed class ReportExportService
{
    public async IAsyncEnumerable<Product> ExportAsync(
        [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken token)
    {
        for (var i = 1; i <= 100_000; i++)
        {
            token.ThrowIfCancellationRequested();
            await Task.Delay(1, token);

            yield return new Product
            {
                Id = i,
                Name = $"Product {i}",
                Price = Random.Shared.Next(10, 1000),
                Category = "Export"
            };
        }
    }
}