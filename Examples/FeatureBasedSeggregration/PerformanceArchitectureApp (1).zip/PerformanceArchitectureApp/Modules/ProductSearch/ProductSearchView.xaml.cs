using System.Windows.Controls;

namespace PerformanceArchitectureApp.Modules.ProductSearch;

public partial class ProductSearchView : UserControl
{
    public ProductSearchView() => InitializeComponent();
}