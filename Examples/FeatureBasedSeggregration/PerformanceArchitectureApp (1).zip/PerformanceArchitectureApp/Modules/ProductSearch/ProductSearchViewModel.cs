using System.Collections.ObjectModel;
using PerformanceArchitectureApp.Shared.Infrastructure;
using PerformanceArchitectureApp.Shared.Models;

namespace PerformanceArchitectureApp.Modules.ProductSearch;

public sealed class ProductSearchViewModel : ObservableObject
{
    private readonly ProductSearchService _service;
    private readonly Debouncer _debouncer = new();
    private string _searchText = string.Empty;

    public ObservableCollection<Product> Results { get; } = [];

    public string SearchText
    {
        get => _searchText;
        set
        {
            if (SetProperty(ref _searchText, value))
                _ = SearchAsync(value);
        }
    }

    public ProductSearchViewModel(ProductSearchService service) => _service = service;

    private async Task SearchAsync(string text)
    {
        await _debouncer.ExecuteAsync(TimeSpan.FromMilliseconds(500), async token =>
        {
            var results = await _service.SearchAsync(text, token);
            Results.Clear();
            foreach (var product in results)
                Results.Add(product);
        });
    }
}