namespace PerformanceArchitectureApp.Modules.ProductSearch;

public sealed class Debouncer
{
    private CancellationTokenSource? _cts;

    public async Task ExecuteAsync(TimeSpan delay, Func<CancellationToken, Task> action)
    {
        var newCts = new CancellationTokenSource();
        var oldCts = Interlocked.Exchange(ref _cts, newCts);
        oldCts?.Cancel();
        oldCts?.Dispose();

        try
        {
            await Task.Delay(delay, newCts.Token);
            await action(newCts.Token);
        }
        catch (OperationCanceledException) { }
    }
}