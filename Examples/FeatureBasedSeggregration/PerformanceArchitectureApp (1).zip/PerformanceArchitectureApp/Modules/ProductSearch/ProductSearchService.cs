using PerformanceArchitectureApp.Shared.Models;

namespace PerformanceArchitectureApp.Modules.ProductSearch;

public sealed class ProductSearchService
{
    private readonly List<Product> _products =
        Enumerable.Range(1, 100_000)
        .Select(i => new Product
        {
            Id = i,
            Name = $"Product {i}",
            Price = Random.Shared.Next(10, 10_000),
            Category = $"Category {i % 10}"
        }).ToList();

    public async Task<List<Product>> SearchAsync(string text, CancellationToken token)
    {
        await Task.Delay(100, token);

        if (string.IsNullOrWhiteSpace(text))
            return [];

        return _products
            .Where(p => p.Name.Contains(text, StringComparison.OrdinalIgnoreCase))
            .Take(100)
            .ToList();
    }
}