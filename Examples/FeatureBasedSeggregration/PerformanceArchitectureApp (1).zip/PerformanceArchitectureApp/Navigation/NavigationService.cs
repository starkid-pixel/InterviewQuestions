using Microsoft.Extensions.DependencyInjection;
using PerformanceArchitectureApp.Shared.Infrastructure;

namespace PerformanceArchitectureApp.Navigation;

public sealed class NavigationService : ObservableObject, INavigationService
{
    private readonly IServiceProvider _serviceProvider;
    private ObservableObject? _currentViewModel;

    public ObservableObject? CurrentViewModel
    {
        get => _currentViewModel;
        private set => SetProperty(ref _currentViewModel, value);
    }

    public NavigationService(IServiceProvider serviceProvider) =>
        _serviceProvider = serviceProvider;

    public void NavigateTo<TViewModel>() where TViewModel : ObservableObject =>
        CurrentViewModel = _serviceProvider.GetRequiredService<TViewModel>();
}