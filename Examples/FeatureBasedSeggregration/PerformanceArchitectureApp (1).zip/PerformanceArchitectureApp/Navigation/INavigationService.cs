using PerformanceArchitectureApp.Shared.Infrastructure;

namespace PerformanceArchitectureApp.Navigation;

public interface INavigationService
{
    ObservableObject? CurrentViewModel { get; }
    void NavigateTo<TViewModel>() where TViewModel : ObservableObject;
}