using System.Threading.Channels;
using ModularMonitoringApp.Core.Models;

namespace ModularMonitoringApp.Infrastructure.Streaming;

public sealed class TelemetryChannel
{
    private readonly Channel<TelemetryData> _channel =
        Channel.CreateBounded<TelemetryData>(
            new BoundedChannelOptions(10_000)
            {
                SingleWriter = true,
                SingleReader = true,
                FullMode = BoundedChannelFullMode.DropOldest
            });

    public ChannelWriter<TelemetryData> Writer => _channel.Writer;
    public ChannelReader<TelemetryData> Reader => _channel.Reader;
}
