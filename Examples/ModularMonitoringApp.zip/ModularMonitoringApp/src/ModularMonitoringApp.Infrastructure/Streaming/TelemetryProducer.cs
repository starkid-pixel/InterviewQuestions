using ModularMonitoringApp.Core.Contracts;

namespace ModularMonitoringApp.Infrastructure.Streaming;

public sealed class TelemetryProducer
{
    private readonly ITelemetryBackend _backend;
    private readonly TelemetryChannel _channel;

    public TelemetryProducer(ITelemetryBackend backend, TelemetryChannel channel)
    {
        _backend = backend;
        _channel = channel;
    }

    public async Task RunAsync(CancellationToken cancellationToken)
    {
        try
        {
            await foreach (var item in _backend.StreamAsync(cancellationToken))
                await _channel.Writer.WriteAsync(item, cancellationToken);
        }
        catch (OperationCanceledException) { }
        finally
        {
            _channel.Writer.TryComplete();
        }
    }
}
