using System.Runtime.CompilerServices;
using ModularMonitoringApp.Core.Contracts;
using ModularMonitoringApp.Core.Models;

namespace ModularMonitoringApp.Infrastructure.Backend;

public sealed class FakeTelemetryBackend : ITelemetryBackend
{
    public async IAsyncEnumerable<TelemetryData> StreamAsync(
        [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        var random = new Random();

        while (!cancellationToken.IsCancellationRequested)
        {
            yield return new TelemetryData(
                $"Device-{random.Next(1, 6)}",
                DateTime.Now,
                random.NextDouble() * 120,
                random.NextDouble() * 50);

            await Task.Delay(2, cancellationToken);
        }
    }
}
