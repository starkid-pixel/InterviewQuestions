using ModularMonitoringApp.Core.Contracts;
using ModularMonitoringApp.Core.Models;

namespace ModularMonitoringApp.Infrastructure.Backend;

public sealed class FakeHistoryBackend : IHistoryBackend
{
    private const int TotalRecords = 10_000_000;

    public async Task<PageResult<TelemetryData>> GetPageAsync(
        PageRequest request,
        CancellationToken cancellationToken)
    {
        await Task.Delay(250, cancellationToken);

        var random = new Random();
        var items = Enumerable.Range(0, request.PageSize)
            .Select(i =>
            {
                var index = request.PageNumber * request.PageSize + i;
                return new TelemetryData(
                    $"Device-{index % 5 + 1}",
                    DateTime.Now.AddMinutes(-index),
                    random.NextDouble() * 100,
                    random.NextDouble() * 50);
            })
            .ToList();

        return new PageResult<TelemetryData>(items, TotalRecords);
    }
}
