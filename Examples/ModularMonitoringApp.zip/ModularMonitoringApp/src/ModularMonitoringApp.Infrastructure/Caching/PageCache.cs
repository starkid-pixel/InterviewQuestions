using System.Collections.Concurrent;
using ModularMonitoringApp.Core.Contracts;
using ModularMonitoringApp.Core.Models;

namespace ModularMonitoringApp.Infrastructure.Caching;

public sealed class PageCache<T> : IPageCache<T>
{
    private readonly ConcurrentDictionary<int, PageResult<T>> _cache = new();

    public bool TryGet(int pageNumber, out PageResult<T>? result)
        => _cache.TryGetValue(pageNumber, out result);

    public void Set(int pageNumber, PageResult<T> result)
        => _cache[pageNumber] = result;
}
