using System.Collections.Concurrent;
using ModularMonitoringApp.Core.Messaging;

namespace ModularMonitoringApp.Infrastructure.Messaging;

public sealed class EventBus : IEventBus
{
    private readonly ConcurrentDictionary<Type, List<Delegate>> _handlers = new();

    public IDisposable Subscribe<TEvent>(Action<TEvent> handler)
    {
        var handlers = _handlers.GetOrAdd(typeof(TEvent), _ => new List<Delegate>());

        lock (handlers)
            handlers.Add(handler);

        return new Subscription(() =>
        {
            lock (handlers)
                handlers.Remove(handler);
        });
    }

    public void Publish<TEvent>(TEvent @event)
    {
        if (!_handlers.TryGetValue(typeof(TEvent), out var handlers))
            return;

        Delegate[] snapshot;
        lock (handlers)
            snapshot = handlers.ToArray();

        foreach (var handler in snapshot)
            ((Action<TEvent>)handler)(@event);
    }

    private sealed class Subscription : IDisposable
    {
        private Action? _unsubscribe;
        public Subscription(Action unsubscribe) => _unsubscribe = unsubscribe;
        public void Dispose() => Interlocked.Exchange(ref _unsubscribe, null)?.Invoke();
    }
}
