using Microsoft.Extensions.DependencyInjection;
using ModularMonitoringApp.Core.Lifecycle;
using ModularMonitoringApp.Core.Navigation;

namespace ModularMonitoringApp.Wpf;

public sealed class NavigationService : INavigationService
{
    private readonly IServiceProvider _services;
    private readonly IRouteRegistry _routes;
    private readonly IShellNavigationHost _shell;

    public NavigationService(IServiceProvider services, IRouteRegistry routes, IShellNavigationHost shell)
    {
        _services = services;
        _routes = routes;
        _shell = shell;
    }

    public async Task NavigateAsync(string route, CancellationToken cancellationToken = default)
    {
        if (_shell.CurrentViewModel is INavigationAware oldVm)
            await oldVm.OnNavigatedFromAsync(cancellationToken);

        var type = _routes.GetViewModelType(route);
        var newVm = _services.GetRequiredService(type);

        _shell.CurrentViewModel = newVm;

        if (newVm is INavigationAware aware)
            await aware.OnNavigatedToAsync(cancellationToken);
    }
}
