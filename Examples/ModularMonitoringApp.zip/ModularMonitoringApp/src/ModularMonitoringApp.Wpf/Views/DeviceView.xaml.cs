using System.Windows.Controls;

namespace ModularMonitoringApp.Wpf.Views;

public partial class DeviceView : UserControl
{
    public DeviceView()
    {
        InitializeComponent();
    }
}
