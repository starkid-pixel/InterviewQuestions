using System.Windows.Controls;

namespace ModularMonitoringApp.Wpf.Views;

public partial class HistoryView : UserControl
{
    public HistoryView()
    {
        InitializeComponent();
    }
}
