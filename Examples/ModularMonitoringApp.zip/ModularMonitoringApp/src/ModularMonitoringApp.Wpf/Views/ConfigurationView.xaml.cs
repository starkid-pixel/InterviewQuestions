using System.Windows.Controls;

namespace ModularMonitoringApp.Wpf.Views;

public partial class ConfigurationView : UserControl
{
    public ConfigurationView()
    {
        InitializeComponent();
    }
}
