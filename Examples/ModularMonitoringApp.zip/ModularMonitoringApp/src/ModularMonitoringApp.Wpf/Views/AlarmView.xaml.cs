using System.Windows.Controls;

namespace ModularMonitoringApp.Wpf.Views;

public partial class AlarmView : UserControl
{
    public AlarmView()
    {
        InitializeComponent();
    }
}
