using System.Windows.Controls;

namespace ModularMonitoringApp.Wpf.Views;

public partial class MonitoringView : UserControl
{
    public MonitoringView()
    {
        InitializeComponent();
    }
}
