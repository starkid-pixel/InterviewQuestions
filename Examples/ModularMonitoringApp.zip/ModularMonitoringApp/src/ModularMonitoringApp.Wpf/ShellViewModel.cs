using System.Windows.Input;
using ModularMonitoringApp.Core.Mvvm;
using ModularMonitoringApp.Core.Navigation;

namespace ModularMonitoringApp.Wpf;

public sealed class ShellViewModel : ObservableObject, IShellNavigationHost
{
    private object? _currentViewModel;

    public object? CurrentViewModel
    {
        get => _currentViewModel;
        set => SetProperty(ref _currentViewModel, value);
    }

    public ICommand NavigateDevicesCommand { get; }
    public ICommand NavigateMonitoringCommand { get; }
    public ICommand NavigateAlarmsCommand { get; }
    public ICommand NavigateHistoryCommand { get; }
    public ICommand NavigateConfigurationCommand { get; }

    public ShellViewModel(INavigationService navigation)
    {
        NavigateDevicesCommand = new AsyncRelayCommand(t => navigation.NavigateAsync("devices", t));
        NavigateMonitoringCommand = new AsyncRelayCommand(t => navigation.NavigateAsync("monitoring", t));
        NavigateAlarmsCommand = new AsyncRelayCommand(t => navigation.NavigateAsync("alarms", t));
        NavigateHistoryCommand = new AsyncRelayCommand(t => navigation.NavigateAsync("history", t));
        NavigateConfigurationCommand = new AsyncRelayCommand(t => navigation.NavigateAsync("configuration", t));
    }
}
