using System.Collections.ObjectModel;
using System.Windows;
using ModularMonitoringApp.Core.Lifecycle;
using ModularMonitoringApp.Core.Messaging;
using ModularMonitoringApp.Core.Models;
using ModularMonitoringApp.Core.Mvvm;

namespace ModularMonitoringApp.Wpf.Modules;

public sealed class AlarmViewModel : ObservableObject, INavigationAware, IDisposable
{
    private readonly IEventBus _eventBus;
    private IDisposable? _subscription;

    public ObservableCollection<AlarmRaised> Alarms { get; } = new();

    public AlarmViewModel(IEventBus eventBus) => _eventBus = eventBus;

    public Task OnNavigatedToAsync(CancellationToken cancellationToken)
    {
        _subscription ??= _eventBus.Subscribe<AlarmRaised>(alarm =>
            Application.Current.Dispatcher.InvokeAsync(() => Alarms.Insert(0, alarm)));

        return Task.CompletedTask;
    }

    public Task OnNavigatedFromAsync(CancellationToken cancellationToken)
    {
        _subscription?.Dispose();
        _subscription = null;
        return Task.CompletedTask;
    }

    public void Dispose() => _subscription?.Dispose();
}
