using ModularMonitoringApp.Core.Mvvm;

namespace ModularMonitoringApp.Wpf.Modules;

public sealed class ConfigurationViewModel : ObservableObject
{
    public string Title => "Configuration Module";
    public string Description => "Configuration can be loaded through a cache-aside service.";
}
