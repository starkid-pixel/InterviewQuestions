using ModularMonitoringApp.Core.Mvvm;

namespace ModularMonitoringApp.Wpf.Modules;

public sealed class DeviceViewModel : ObservableObject
{
    public string Title => "Devices Module";
    public string Description => "Device management module.";
}
