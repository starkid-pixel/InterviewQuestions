using System.Collections.ObjectModel;
using System.Windows.Input;
using ModularMonitoringApp.Core.Contracts;
using ModularMonitoringApp.Core.Lifecycle;
using ModularMonitoringApp.Core.Models;
using ModularMonitoringApp.Core.Mvvm;

namespace ModularMonitoringApp.Wpf.Modules;

public sealed class HistoryViewModel : ObservableObject, INavigationAware, IDisposable
{
    private readonly IHistoryBackend _backend;
    private readonly IPageCache<TelemetryData> _cache;
    private CancellationTokenSource? _requestCts;
    private int _currentPage;

    public int CurrentPage
    {
        get => _currentPage;
        private set => SetProperty(ref _currentPage, value);
    }

    public ObservableCollection<TelemetryData> Items { get; } = new();

    public ICommand NextPageCommand { get; }
    public ICommand PreviousPageCommand { get; }

    public HistoryViewModel(IHistoryBackend backend, IPageCache<TelemetryData> cache)
    {
        _backend = backend;
        _cache = cache;

        NextPageCommand = new AsyncRelayCommand(t => LoadPageAsync(CurrentPage + 1, t));
        PreviousPageCommand = new AsyncRelayCommand(t => LoadPageAsync(Math.Max(0, CurrentPage - 1), t));
    }

    public Task OnNavigatedToAsync(CancellationToken cancellationToken)
        => Items.Count == 0 ? LoadPageAsync(0, cancellationToken) : Task.CompletedTask;

    public Task OnNavigatedFromAsync(CancellationToken cancellationToken)
    {
        _requestCts?.Cancel();
        return Task.CompletedTask;
    }

    public async Task LoadPageAsync(int pageNumber, CancellationToken outerToken)
    {
        _requestCts?.Cancel();
        _requestCts?.Dispose();
        _requestCts = CancellationTokenSource.CreateLinkedTokenSource(outerToken);

        try
        {
            var token = _requestCts.Token;

            if (!_cache.TryGet(pageNumber, out var page) || page is null)
            {
                page = await _backend.GetPageAsync(
                    new PageRequest(pageNumber, 100), token);

                _cache.Set(pageNumber, page);
            }

            token.ThrowIfCancellationRequested();

            Items.Clear();
            foreach (var item in page.Items)
                Items.Add(item);

            CurrentPage = pageNumber;
        }
        catch (OperationCanceledException) { }
    }

    public void Dispose()
    {
        _requestCts?.Cancel();
        _requestCts?.Dispose();
    }
}
