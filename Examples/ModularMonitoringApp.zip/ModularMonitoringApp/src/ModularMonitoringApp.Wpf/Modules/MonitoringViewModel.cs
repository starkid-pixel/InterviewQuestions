using System.Collections.Concurrent;
using System.Collections.ObjectModel;
using System.Windows;
using ModularMonitoringApp.Core.Lifecycle;
using ModularMonitoringApp.Core.Messaging;
using ModularMonitoringApp.Core.Models;
using ModularMonitoringApp.Core.Mvvm;
using ModularMonitoringApp.Infrastructure.Streaming;

namespace ModularMonitoringApp.Wpf.Modules;

public sealed class MonitoringViewModel : ObservableObject, INavigationAware, IDisposable
{
    private readonly TelemetryChannel _channel;
    private readonly IEventBus _eventBus;
    private readonly ConcurrentQueue<TelemetryData> _pending = new();

    private CancellationTokenSource? _cts;
    private Task? _consumerTask;
    private Task? _uiTask;

    public ObservableCollection<TelemetryData> Items { get; } = new();

    public MonitoringViewModel(TelemetryChannel channel, IEventBus eventBus)
    {
        _channel = channel;
        _eventBus = eventBus;
    }

    public Task OnNavigatedToAsync(CancellationToken cancellationToken)
    {
        if (_cts is not null) return Task.CompletedTask;

        _cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        _consumerTask = ConsumeAsync(_cts.Token);
        _uiTask = UpdateUiAsync(_cts.Token);

        return Task.CompletedTask;
    }

    public async Task OnNavigatedFromAsync(CancellationToken cancellationToken)
    {
        _cts?.Cancel();

        try
        {
            var tasks = new[] { _consumerTask, _uiTask }
                .Where(t => t is not null)
                .Cast<Task>();

            await Task.WhenAll(tasks);
        }
        catch (OperationCanceledException) { }
        finally
        {
            _cts?.Dispose();
            _cts = null;
            _consumerTask = null;
            _uiTask = null;
        }
    }

    private async Task ConsumeAsync(CancellationToken token)
    {
        try
        {
            await foreach (var item in _channel.Reader.ReadAllAsync(token))
            {
                if (item.Temperature > 100)
                    _eventBus.Publish(new AlarmRaised(
                        item.DeviceId,
                        $"High temperature: {item.Temperature:F1}",
                        item.Timestamp));

                _pending.Enqueue(item);
            }
        }
        catch (OperationCanceledException) { }
    }

    private async Task UpdateUiAsync(CancellationToken token)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromMilliseconds(250));

        try
        {
            while (await timer.WaitForNextTickAsync(token))
            {
                var batch = new List<TelemetryData>();

                while (_pending.TryDequeue(out var item))
                    batch.Add(item);

                if (batch.Count == 0) continue;

                await Application.Current.Dispatcher.InvokeAsync(() =>
                {
                    foreach (var item in batch)
                        Items.Add(item);

                    const int maxItems = 2000;
                    while (Items.Count > maxItems)
                        Items.RemoveAt(0);
                });
            }
        }
        catch (OperationCanceledException) { }
    }

    public void Dispose()
    {
        _cts?.Cancel();
        _cts?.Dispose();
    }
}
