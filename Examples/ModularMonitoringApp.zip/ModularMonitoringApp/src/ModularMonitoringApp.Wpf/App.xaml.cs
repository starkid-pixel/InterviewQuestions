using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using ModularMonitoringApp.Core.Contracts;
using ModularMonitoringApp.Core.Messaging;
using ModularMonitoringApp.Core.Navigation;
using ModularMonitoringApp.Infrastructure.Backend;
using ModularMonitoringApp.Infrastructure.Caching;
using ModularMonitoringApp.Infrastructure.Messaging;
using ModularMonitoringApp.Infrastructure.Streaming;
using ModularMonitoringApp.Wpf.Modules;

namespace ModularMonitoringApp.Wpf;

public partial class App : Application
{
    private IHost? _host;
    private CancellationTokenSource? _appCts;

    private async void Application_Startup(object sender, StartupEventArgs e)
    {
        _appCts = new CancellationTokenSource();
        var builder = Host.CreateApplicationBuilder();

        builder.Services.AddSingleton<IRouteRegistry, RouteRegistry>();
        builder.Services.AddSingleton<INavigationService, NavigationService>();

        builder.Services.AddSingleton<ShellViewModel>();
        builder.Services.AddSingleton<IShellNavigationHost>(
            p => p.GetRequiredService<ShellViewModel>());
        builder.Services.AddSingleton<MainWindow>();

        builder.Services.AddSingleton<TelemetryChannel>();
        builder.Services.AddSingleton<ITelemetryBackend, FakeTelemetryBackend>();
        builder.Services.AddSingleton<TelemetryProducer>();
        builder.Services.AddSingleton<IHistoryBackend, FakeHistoryBackend>();
        builder.Services.AddSingleton<IPageCache<ModularMonitoringApp.Core.Models.TelemetryData>,
            PageCache<ModularMonitoringApp.Core.Models.TelemetryData>>();
        builder.Services.AddSingleton<IEventBus, EventBus>();

        builder.Services.AddSingleton<DeviceViewModel>();
        builder.Services.AddSingleton<MonitoringViewModel>();
        builder.Services.AddSingleton<AlarmViewModel>();
        builder.Services.AddSingleton<HistoryViewModel>();
        builder.Services.AddSingleton<ConfigurationViewModel>();

        _host = builder.Build();

        RouteRegistration.Register(_host.Services.GetRequiredService<IRouteRegistry>());

        _ = _host.Services.GetRequiredService<TelemetryProducer>()
            .RunAsync(_appCts.Token);

        var window = _host.Services.GetRequiredService<MainWindow>();
        window.Show();

        await _host.Services.GetRequiredService<INavigationService>()
            .NavigateAsync("devices", _appCts.Token);
    }

    private void Application_Exit(object sender, ExitEventArgs e)
    {
        _appCts?.Cancel();
        _host?.Dispose();
        _appCts?.Dispose();
    }
}
