using ModularMonitoringApp.Core.Navigation;
using ModularMonitoringApp.Wpf.Modules;

namespace ModularMonitoringApp.Wpf;

public static class RouteRegistration
{
    public static void Register(IRouteRegistry routes)
    {
        routes.Register("devices", typeof(DeviceViewModel));
        routes.Register("monitoring", typeof(MonitoringViewModel));
        routes.Register("alarms", typeof(AlarmViewModel));
        routes.Register("history", typeof(HistoryViewModel));
        routes.Register("configuration", typeof(ConfigurationViewModel));
    }
}
