using ModularMonitoringApp.Core.Models;

namespace ModularMonitoringApp.Core.Contracts;

public interface IPageCache<T>
{
    bool TryGet(int pageNumber, out PageResult<T>? result);
    void Set(int pageNumber, PageResult<T> result);
}
