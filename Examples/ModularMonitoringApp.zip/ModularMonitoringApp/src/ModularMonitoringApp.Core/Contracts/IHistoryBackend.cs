using ModularMonitoringApp.Core.Models;

namespace ModularMonitoringApp.Core.Contracts;

public interface IHistoryBackend
{
    Task<PageResult<TelemetryData>> GetPageAsync(
        PageRequest request,
        CancellationToken cancellationToken);
}
