using ModularMonitoringApp.Core.Models;

namespace ModularMonitoringApp.Core.Contracts;

public interface ITelemetryBackend
{
    IAsyncEnumerable<TelemetryData> StreamAsync(CancellationToken cancellationToken);
}
