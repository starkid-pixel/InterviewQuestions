namespace ModularMonitoringApp.Core.Navigation;

public interface INavigationService
{
    Task NavigateAsync(string route, CancellationToken cancellationToken = default);
}
