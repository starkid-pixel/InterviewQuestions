namespace ModularMonitoringApp.Core.Navigation;

public sealed class RouteRegistry : IRouteRegistry
{
    private readonly Dictionary<string, Type> _routes =
        new(StringComparer.OrdinalIgnoreCase);

    public void Register(string route, Type viewModelType)
        => _routes[route] = viewModelType;

    public Type GetViewModelType(string route)
        => _routes.TryGetValue(route, out var type)
            ? type
            : throw new InvalidOperationException($"Route '{route}' is not registered.");
}
