namespace ModularMonitoringApp.Core.Navigation;

public interface IShellNavigationHost
{
    object? CurrentViewModel { get; set; }
}
