namespace ModularMonitoringApp.Core.Navigation;

public interface IRouteRegistry
{
    void Register(string route, Type viewModelType);
    Type GetViewModelType(string route);
}
