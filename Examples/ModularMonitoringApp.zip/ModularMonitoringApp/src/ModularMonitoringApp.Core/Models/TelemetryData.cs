namespace ModularMonitoringApp.Core.Models;

public sealed record TelemetryData(
    string DeviceId,
    DateTime Timestamp,
    double Temperature,
    double Pressure);
