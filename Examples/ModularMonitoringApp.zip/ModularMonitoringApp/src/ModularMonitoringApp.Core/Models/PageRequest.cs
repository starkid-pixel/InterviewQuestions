namespace ModularMonitoringApp.Core.Models;

public sealed record PageRequest(int PageNumber, int PageSize);
