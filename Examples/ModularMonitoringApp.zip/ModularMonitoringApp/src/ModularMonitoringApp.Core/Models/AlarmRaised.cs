namespace ModularMonitoringApp.Core.Models;

public sealed record AlarmRaised(
    string DeviceId,
    string Message,
    DateTime Timestamp);
