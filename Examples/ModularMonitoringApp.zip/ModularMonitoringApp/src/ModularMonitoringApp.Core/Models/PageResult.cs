namespace ModularMonitoringApp.Core.Models;

public sealed record PageResult<T>(IReadOnlyList<T> Items, int TotalCount);
