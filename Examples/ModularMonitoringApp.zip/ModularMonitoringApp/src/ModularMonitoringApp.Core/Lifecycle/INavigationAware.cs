namespace ModularMonitoringApp.Core.Lifecycle;

public interface INavigationAware
{
    Task OnNavigatedToAsync(CancellationToken cancellationToken);
    Task OnNavigatedFromAsync(CancellationToken cancellationToken);
}
